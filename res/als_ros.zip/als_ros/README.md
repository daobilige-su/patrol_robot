This directory is the als_ros package.

If you don't want to make a new ROS workspace, please copy this directory to your workspace.